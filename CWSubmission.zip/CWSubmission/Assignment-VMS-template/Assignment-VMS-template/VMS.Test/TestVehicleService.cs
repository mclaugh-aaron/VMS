using System;
using Xunit;

// importing dependencies from the Data Project
using VMS.Data.Models;
using VMS.Data.Services;

namespace VMS.Test
{
    public class VehicleServiceTest
    {
       // define a set of appropriate tests to test the vehicle service class
        private readonly IVehicleService svc;

        public VehicleServiceTest()
        {
            svc = new VehicleDbService();

            svc.Initialise(); //to ensure database is empty before each test
        }

        [Fact]
        public void AddVehicle_WhenNone_ShouldSetAllProperties()
        {
            //arrange
            var v = svc.AddVehicle(new Vehicle{Make = "xxx", Model = "xxx", DateRegistered=new DateTime(1998, 05,05), Transmission = "xxx", Co2Rating=200, FuelType="xxx", BodyType="xxx", Doors=4, PhotoUrl="xxx"});
            //act
            Assert.NotNull(v);
            //Assert properties are set
            Assert.Equal(v.Id, v.Id);
            Assert.Equal("xxx", v.Make);
            Assert.Equal("xxx", v.Model);
            Assert.Equal(new DateTime(1998,05,05), v.DateRegistered);
            Assert.Equal("xxx", v.Transmission);
            Assert.Equal(200, v.Co2Rating);
            Assert.Equal("xxx", v.FuelType);
            Assert.Equal("xxx", v.BodyType);
            Assert.Equal(4, v.Doors);
            Assert.Equal("xxx", v.PhotoUrl);
        }

        [Fact]
        public void AddVehicle_WhenDuplicate_ShouldReturnNull()
        {
            
            var v1 = svc.AddVehicle(new Vehicle{Make = "xxx", Model = "xxx", DateRegistered=new DateTime(1998, 05,05), Transmission = "xxx", Co2Rating=200, FuelType="xxx", BodyType="xxx", Doors=4, PhotoUrl="xxx"});
            var v2  = svc.AddVehicle(new Vehicle{Make = "xxx", Model = "xxx", DateRegistered=new DateTime(1998, 05,05), Transmission = "xxx", Co2Rating=200, FuelType="xxx", BodyType="xxx", Doors=4, PhotoUrl="xxx"});
        
            Assert.NotNull(v1);
            Assert.Null(v2);
        
        }

        [Fact] 
        public void GetAllVehicles_WhenNone_ShouldReturn0()
        {
            
            var vehicles = svc.GetAllVehicles();
            var count = vehicles.Count;

            Assert.Equal(0, count);
        }

        [Fact]
        public void GetVehicles_With2Added_ShouldReturn2()
        {
            // arrange
            var v1 = svc.AddVehicle(new Vehicle{Make = "xxx", Model = "xxx", DateRegistered=new DateTime(1998, 05,05), RegPlate="xxx", Transmission = "xxx", Co2Rating=200, FuelType="xxx", BodyType="xxx", Doors=4, PhotoUrl="xxx"});
            var v2  = svc.AddVehicle(new Vehicle{Make = "yyy", Model = "yyy", DateRegistered=new DateTime(1998, 05,05), RegPlate="yyy", Transmission = "yyy", Co2Rating=200, FuelType="yyy", BodyType="yyy", Doors=4, PhotoUrl="xxx"});

            // act
            var vehicles = svc.GetAllVehicles();
            var count = vehicles.Count;

            // assert
            Assert.Equal(2, count);
        }

        [Fact] 
        public void GetVehicle_WhenNone_ShouldReturnNull()
        {
            // act 
            var vehicle = svc.GetVehicleById(1); // non existent vehicle

            // assert
            Assert.Null(vehicle);
        }

        [Fact] 
        public void GetVehicle_WhenAdded_ShouldReturnVehicle()
        {
            //arrange
            var v = svc.AddVehicle(new Vehicle{Make = "xxx", Model = "xxx", DateRegistered=new DateTime(1998, 05,05), RegPlate="xxx", Transmission = "xxx", Co2Rating=200, FuelType="xxx", BodyType="xxx", Doors=4, PhotoUrl="xxx"});
            //act
            var nv = svc.GetVehicleById(v.Id);

            // assert
            Assert.NotNull(nv);
            Assert.Equal(v.Id, nv.Id);
        }

        [Fact]
        public void DeleteVehicle_ThatExists_ShouldReturnTrue()
        {
            // act 
            var v = svc.AddVehicle(new Vehicle{Make = "xxx", Model = "xxx", DateRegistered=new DateTime(1998, 05,05), RegPlate="xxx", Transmission = "xxx", Co2Rating=200, FuelType="xxx", BodyType="xxx", Doors=4, PhotoUrl="xxx"});

            var deleted = svc.DeleteVehicle(v.Id);

            // assert
            Assert.True(deleted);
        }

        [Fact]
        public void DeleteVehicle_ThatDoesntExist_ShouldReturnFalse()
        {
            // act 	
            var deleted = svc.DeleteVehicle(8);

            // assert
            Assert.False(deleted);
        }

        [Fact]
        public void Update_ExistingVehicle_ShouldChangeDetails()
        {
             // act 
            var v = svc.AddVehicle(new Vehicle{Make = "xxx", Model = "xxx", DateRegistered=new DateTime(1998, 05,05), RegPlate="xxx", Transmission = "xxx", Co2Rating=200, FuelType="xxx", BodyType="xxx", Doors=4, PhotoUrl="xxx"});
        
            //act
            v.Make="BMW";
            svc.UpdateVehicle(v.Id, v);
            var vu = svc.GetVehicleById(v.Id);

            //Assert
            Assert.Equal(v.Make, vu.Make);
        }

        [Fact]
        public void GetServiceByID_ShouldReturnService()
        {
            var v = svc.AddVehicle(new Vehicle{Make = "xxx", Model = "xxx", DateRegistered=new DateTime(1998, 05, 05), RegPlate="xxx", Transmission = "xxx", Co2Rating=200, FuelType="xxx", BodyType="xxx", Doors=4, PhotoUrl="xxx"});
            var s = svc.AddService(new Service{VehicleId=v.Id, Servicer="Jim McDonald", DateOfService= new DateTime(2019, 01, 05), WorkCarriedOut="An engine oil change and filter replacement.", Mileage=65000, ServiceCost=59.99});

            var ns = svc.GetServiceById(s.ID);

            Assert.NotNull(ns);
            Assert.Equal(s.ID, ns.ID);
        }

        [Fact]
        public void AddNewService_ShouldAdd()
        {
        var v = svc.AddVehicle(new Vehicle{Make = "xxx", Model = "xxx", DateRegistered=new DateTime(1998, 05, 05), RegPlate="xxx", Transmission = "xxx", Co2Rating=200, FuelType="xxx", BodyType="xxx", Doors=4, PhotoUrl="xxx"});
        var s = svc.AddService(new Service{VehicleId=v.Id, Servicer="Jim McDonald", DateOfService= new DateTime(2019, 01, 05), WorkCarriedOut="An engine oil change and filter replacement.", Mileage=65000, ServiceCost=59.99});

        var s2 = svc.GetServiceById(s.ID);

        Assert.NotNull(s2);
        }

        [Fact]
        public void DeleteService_ShouldDReturnFalse()
        {
        var v = svc.AddVehicle(new Vehicle{Make = "xxx", Model = "xxx", DateRegistered=new DateTime(1998, 05, 05), RegPlate="xxx", Transmission = "xxx", Co2Rating=200, FuelType="xxx", BodyType="xxx", Doors=4, PhotoUrl="xxx"});
        var s = svc.AddService(new Service{VehicleId=v.Id, Servicer="Jim McDonald", DateOfService= new DateTime(2019, 01, 05), WorkCarriedOut="An engine oil change and filter replacement.", Mileage=65000, ServiceCost=59.99});

        var deleted = svc.DeleteService(s.ID);

        Assert.True(deleted);
        }

        [Fact]
        public void DeleteService_ThatDoesntExist_ShouldReturnFalse()
        {
        // act 	
        var deleted = svc.DeleteService(8);

        // assert
        Assert.False(deleted);
        }

        [Fact]
        public void GetAllVehicles_ReturnsVehicles()
        {
         var vehicles = svc.GetAllVehicles();
        
        Assert.NotNull(vehicles);
        }

        [Fact]
        public void GetAllVehicles_ReturnsInOrderOfID()
        {
            var v1 = svc.AddVehicle(new Vehicle{Make = "xxx", Model = "xxx", DateRegistered=new DateTime(1998, 05,05), RegPlate="xxx", Transmission = "xxx", Co2Rating=200, FuelType="xxx", BodyType="xxx", Doors=4, PhotoUrl="xxx"});
            var v2  = svc.AddVehicle(new Vehicle{Make = "yyy", Model = "yyy", DateRegistered=new DateTime(1998, 05,05), RegPlate="yyy", Transmission = "yyy", Co2Rating=200, FuelType="yyy", BodyType="yyy", Doors=4, PhotoUrl="xxx"});

            
            
        }

    }
}