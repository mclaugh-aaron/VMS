using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System;

namespace VMS.Data.Models
{      
    //Class representing a vehicle table in our database
    public class Vehicle
    {
    //Int field will be primary key - vehicle Id
    public int Id { get; set; }
    [Required]    
    public string Make { get; set; }
    [Required]
    public string Model { get; set; }
    [Required]
    public DateTime DateRegistered { get; set; }
    [Required]
    public string RegPlate { get; set; }
    [Required]
    public int CarAge => (DateTime.Now - DateRegistered).Days / 365;
    [Required]
    public string Transmission { get; set; }
    [Required]
    public int Co2Rating { get; set; }
    [Required]
    public string  FuelType { get; set; }
    [Required]
    public string BodyType { get; set; }
    [Required]
    [Range(2,5)]
    public int Doors { get; set; }
    [Required]
    [Url]   
    public string PhotoUrl { get; set; }

    // navigation property to access service's list (1:N)
    public ICollection<Service> Services {get; set;}

        
    }
}