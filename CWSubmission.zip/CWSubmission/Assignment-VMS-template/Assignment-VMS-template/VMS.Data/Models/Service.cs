using System;
using System.ComponentModel.DataAnnotations;

namespace VMS.Data.Models
{
    public class Service
    {     
        //Int field will be primary key - vehicle Id
        public int ID { get; set; }
        [Required]
        public string Servicer { get; set; }
        [Required]
        public DateTime DateOfService { get; set; }

        [Required]
        [StringLength(600, MinimumLength=3)]
        public string WorkCarriedOut { get; set; }
        [Required]
        public int Mileage { get; set; }
        [Required]
        public double ServiceCost { get; set; }
        [Required]

        // Foreign key relating to Vehicle Serviced
        public int VehicleId { get; set; }
        public Vehicle Vehicle {get; set;}

    }
}