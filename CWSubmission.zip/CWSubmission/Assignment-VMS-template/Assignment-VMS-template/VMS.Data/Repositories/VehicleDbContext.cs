using System;

// import the Models
using VMS.Data.Models;
using Microsoft.EntityFrameworkCore;

// required to add console logging
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace VMS.Data.Repositories
{
    public class VehicleDbContext : DbContext
    {
         // create DbSets for the models
        public DbSet<Vehicle> Vehicles  {get; set; }    
        public DbSet<Service> Services {get; set;  }
        

        //Ensure the database is deleted then created again every time the app is run
        public void Initialise()
        {
            Database.EnsureDeleted();
            Database.EnsureCreated();
        }
        //creates DbSet for Vehicles and Services

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Filename=VMS.db").UseLoggerFactory(new ServiceCollection()
		.AddLogging(builder => builder.AddConsole())
		.BuildServiceProvider()
		.GetService<ILoggerFactory>());

        }

        // Creates a Sql Query console logger that can be added to context for debugging 
        private static ILoggerFactory GetConsoleLoggerFactory()
        {
            IServiceCollection serviceCollection = new ServiceCollection();
            serviceCollection.AddLogging(builder => builder.AddConsole().AddFilter(DbLoggerCategory.Query.Name, LogLevel.Information));
            return serviceCollection.BuildServiceProvider().GetService<ILoggerFactory>();
        }
    }
}