using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

using VMS.Data.Models;
using VMS.Data.Repositories;

namespace VMS.Data.Services
{
    public class VehicleDbService : IVehicleService
    {
        private readonly VehicleDbContext db;

        public VehicleDbService()
        {
            db = new VehicleDbContext();
        }
        public void Initialise()
        {
            db.Initialise();
        }
       
        // Vehicle Management
        public Vehicle AddVehicle(Vehicle v)
        {
            var exists = db.Vehicles.FirstOrDefault(e => e.RegPlate == v.RegPlate); //as reg plate is unique property check to see if already added

            if(exists != null)
            {
                return null; //if vehicle already exists it will not be added
            }
            var n = new Vehicle
            {
                Make = v.Make,
                Model = v.Model,
                DateRegistered = v.DateRegistered,
                RegPlate = v.RegPlate,
                Transmission = v.Transmission,
                Co2Rating = v.Co2Rating,                //add details for new vehicle
                FuelType = v.FuelType,
                BodyType = v.BodyType,
                Doors = v.Doors,
                PhotoUrl = v.PhotoUrl 
            };
            db.Vehicles.Add(n);     //add new vehicle
            db.SaveChanges();       //save changes
            
            return n; //return newly added Vehicle
        }

        public bool DeleteVehicle(int id)
        {
            var v = GetVehicleById(id); //check if vehicle exists
            if(v == null)
            {
                return false;   //if vehicle doesnt exist return false
            }
            db.Vehicles.Remove(v);
            db.SaveChanges();
            return true;    // if vehicle is found, remove from DB, save changes, return true
        }

        public IList<Vehicle> GetAllVehicles(string sortOrder)             //sort order passed in as parameter
        {
            switch(sortOrder)
            {
                case "#":
                return db.Vehicles.OrderBy(v => v.Id).ToList();    //sorts vehicles by id number
   
                case "Make":
                return db.Vehicles.OrderBy(v => v.Make).ToList();   //sorts vehicle by by make
        
                case "Model":
                return db.Vehicles.OrderBy(v => v.Model).ToList();  //sorts vehicles by model
        
                case "Year":
                return db.Vehicles.OrderByDescending(v => v.DateRegistered).ToList();   //sorts vehicle in order by date registered
        
                case "Fuel":
                return db.Vehicles.OrderBy(v => v.FuelType).ToList();       //sorted by fuel type
         
                default:
                return db.Vehicles.OrderBy(v => v.Id).ToList();     //the default is to sort by ID number
            } 
        }
   
  
        public Vehicle GetVehicleById(int id)
        {
            var vehicle = db.Vehicles.Include(v => v.Services).FirstOrDefault(v => v.Id == id); //return vehicle specified by parameter

            if(vehicle==null)           //if vehicle does not exist return null
            {
                return null;
            }
            return vehicle;
        }

        public Vehicle UpdateVehicle(int id, Vehicle v)
        {
            var vehicle = GetVehicleById(id);   //search for vehicle using ID
            if(vehicle == null)
            {
                return null;                   //return null if vehicle not found
            }
                vehicle.Make = v.Make;
                vehicle.Model = v.Model;
                vehicle.DateRegistered = v.DateRegistered;
                vehicle.RegPlate = v.RegPlate;
                vehicle.Transmission = v.Transmission;      //update the details of vehicle retrieved
                vehicle.Co2Rating = v.Co2Rating;
                vehicle.FuelType = v.FuelType;
                vehicle.BodyType = v.BodyType;
                vehicle.Doors = v.Doors;
                vehicle.PhotoUrl = v.PhotoUrl;

                db.SaveChanges();
                return vehicle;
        }


        // Service Management
        public Service AddService(Service s)
        {
            var service = new Service{
                VehicleId = s.VehicleId,
                Servicer = s.Servicer,
                DateOfService = s.DateOfService,            //Add new service details
                WorkCarriedOut = s.WorkCarriedOut,
                Mileage = s.Mileage,
                ServiceCost = s.ServiceCost
            };
            db.Services.Add(service);                   //Add new service to database
            db.SaveChanges();                           //save changed
            return service;                            
        }

        public Service AddNewService(int vehicleid, string servicer, string description, double cost, int miles)
        {
          
              var s = new Service
              {
                  VehicleId = vehicleid,                //Add new service to the vehicle ID passed in as parameter
                  Servicer = servicer,
                  WorkCarriedOut = description,
                  ServiceCost = cost,
                  DateOfService = DateTime.Now,
                  Mileage = miles,
              };
              db.Services.Add(s);           //add this service to db
              db.SaveChanges();             //save changes
              return s;
        }


        public Service GetServiceById(int id)
         {
            var service = db.Services.Include(v => v.Vehicle).FirstOrDefault(s => s.ID == id);  //get service by using unique Id

            if(service == null)
            {
                return null;       //If service does not exist return null
            }
            return service;
        }

        public bool DeleteService(int id)
        {
            var service = db.Services.FirstOrDefault(s => s.ID == id);
            
            if(service ==null)
            {                           //first check to see if service exists, if it doesnt then return false
                return false;
            }

            db.Services.Remove(service);        //remove service
            db.SaveChanges();                   //save changes
        
            return true;
        }

    }
}