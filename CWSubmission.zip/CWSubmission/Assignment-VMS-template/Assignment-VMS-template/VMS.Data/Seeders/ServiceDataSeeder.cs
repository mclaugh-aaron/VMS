using System;
using System.Collections.Generic;
using VMS.Data.Models;
using VMS.Data.Repositories;
using VMS.Data.Services;


namespace VMS.Data.Seeders
{
    public static class ServiceDataSeeder
    {
   
        public static void Seed(IVehicleService svc)
        {    
            svc.Initialise();

            //create vehicles
            var v1 = new Vehicle{Make="Ford", Model="Ka", DateRegistered= new DateTime(2018, 01, 01), RegPlate="JNZ 5392", Transmission="Automatic", Co2Rating=100, BodyType="Hatchback", FuelType="Petrol", Doors=3, PhotoUrl="https://pngimage.net/wp-content/uploads/2018/06/ford-ka-2017-png.png"};
            var v2 = new Vehicle{Make="Ford", Model="Fiesta", DateRegistered=new DateTime(2019, 01, 01), RegPlate="MKZ 8123", Transmission="Manual", Co2Rating=82, BodyType="Hatchback", FuelType="Petrol", Doors=5, PhotoUrl="https://assets.gcs.ehi.com/content/enterprise_cros/data/vehicle/bookingCountries/IE/CARS/ECMN.doi.200.high.imageSmallThreeQuarterNodePath.png/1492780333821.png"};
            var v3 = new Vehicle{Make="Opel", Model="Astra", DateRegistered=new DateTime(2018, 06, 10), RegPlate="MUI 1916", Transmission="Manual", Co2Rating=112, BodyType="Saloon", FuelType="Hybrid", Doors=5, PhotoUrl="https://assets.gcs.ehi.com/content/enterprise_cros/data/vehicle/bookingCountries/IE/CARS/CCMR.doi.200.high.imageSmallThreeQuarterNodePath.png/1492780324562.png"};
            var v4 = new Vehicle{Make="Nissan", Model="Qashqai", DateRegistered=new DateTime(2019, 01, 01), RegPlate="JUI 1989", Transmission="Manual", Co2Rating=110, BodyType="SUV", FuelType="Diesel", Doors=5, PhotoUrl="https://assets.gcs.ehi.com/content/enterprise_cros/data/vehicle/bookingCountries/IE/SUVS/IFMR.doi.200.high.imageSmallThreeQuarterNodePath.png/1492780473714.png"};
            var v5 = new Vehicle{Make="Opel", Model="Zafira", DateRegistered=new DateTime(2018, 06, 10), RegPlate="GUI 119", Transmission="Manual", Co2Rating=102, BodyType="MPV", FuelType="Petrol", Doors=5, PhotoUrl="https://assets.gcs.ehi.com/content/enterprise_cros/data/vehicle/bookingCountries/IE/PEOPLE-CARRIERS/SVMR.doi.200.high.imageSmallThreeQuarterNodePath.png/1492744291850.png"};
            var v6 = new Vehicle{Make="Volkswagen", Model="Polo", DateRegistered=new DateTime(2019, 03, 01), RegPlate="MUI 555", Transmission="Manual", Co2Rating=102, BodyType="Hatchback", FuelType="Electric", Doors=5, PhotoUrl="https://images.hertz.com/vehicles/220x128/ZEIEECMN999.jpg"};
            var v7 = new Vehicle{Make="Mitsubishi", Model="Mirage", DateRegistered=new DateTime(2019,01, 03), RegPlate="JUI 688", Transmission="Manual", Co2Rating=90, BodyType="Hatchback", FuelType="Petrol", Doors=3, PhotoUrl="https://www.mitsubishi-motors.ca/media/vehicle/nav/2020-mitsubishi-mirage-nav-large-100a5f.png"};
            var v8 = new Vehicle{Make="Audi", Model="A4", DateRegistered = new DateTime(2019,02,03), RegPlate="BAX 1917", Transmission="Manual", Co2Rating=100, BodyType="Estate", FuelType="Diesel", Doors=5, PhotoUrl="https://cdn1.carbuyer.co.uk/sites/carbuyer_d7/files/audi_a6_avant_cutout.jpg"};
            var v9 = new Vehicle{Make="Land Rover", Model="Defender", DateRegistered =new DateTime(2019, 05,04), RegPlate="MUI 4X4", Transmission="Manual", Co2Rating=180, BodyType="4 x 4", FuelType="Petrol", Doors=5, PhotoUrl="https://i.pinimg.com/originals/18/f6/10/18f6109d6cd6ada34fd04a14b515c9eb.png"};

            //add vehicles
            v1 = svc.AddVehicle(v1);
            v2 = svc.AddVehicle(v2);
            v3 = svc.AddVehicle(v3);
            v4 = svc.AddVehicle(v4);
            v5 = svc.AddVehicle(v5);
            v6 = svc.AddVehicle(v6);
            v7 = svc.AddVehicle(v7);
            v8 = svc.AddVehicle(v8);
            v9 = svc.AddVehicle(v9);



            //create services
            var s1 = new Service{VehicleId=v1.Id, Servicer="Jim McDonald", DateOfService= new DateTime(2019, 05, 01), WorkCarriedOut="An engine oil change and filter replacement.", Mileage=65000, ServiceCost=59.99};
            var s2 = new Service{VehicleId=v1.Id, Servicer="James May", DateOfService=new DateTime(2020, 01, 10), WorkCarriedOut="Checked lights, tyres, exhaust and operations of brakes and steering.", Mileage=75000, ServiceCost=79.99};
            var s3 = new Service{VehicleId=v2.Id, Servicer="Kevin Webster", DateOfService=new DateTime(2020, 06, 01),WorkCarriedOut="Engine tuned to peak performance", Mileage= 50000, ServiceCost=120.99 };
            var s4 = new Service{VehicleId=v3.Id, Servicer="B.A Baracus", DateOfService=new DateTime(2019, 06, 10), WorkCarriedOut="Check hydraulic fluid and coolant levels.", Mileage=50000, ServiceCost=60.99};
            var s5 = new Service{VehicleId=v4.Id, Servicer="Dominic Toretto", DateOfService=new DateTime(2020, 02, 01), WorkCarriedOut="Steering alignment", Mileage=55000, ServiceCost=99.99};
            var s6 = new Service{VehicleId=v5.Id, Servicer="Ché W. Bacca", DateOfService=new DateTime(2019, 06, 05), WorkCarriedOut="Testing the car’s battery condition.", Mileage=39595, ServiceCost=40.99};
            var s7 = new Service{VehicleId=v5.Id, Servicer="Montgomery Scott", DateOfService=new DateTime(2020, 05, 06), WorkCarriedOut="Suspension checks", Mileage= 48676, ServiceCost=50.99};
            var s8 = new Service{VehicleId=v6.Id, Servicer="Brian O'Conner", DateOfService=new DateTime(2020, 02, 20), WorkCarriedOut="top ups of the brake fluid and antifreeze, more brake checks, inspection of the engine", Mileage=13595, ServiceCost=83.99};
            var s9 = new Service{VehicleId=v7.Id, Servicer="Dominic Toretto", DateOfService=new DateTime(2020,03,02), WorkCarriedOut="New tyres put on vehicle", Mileage=15000, ServiceCost=219.99};
            var s10 = new Service{VehicleId=v8.Id, Servicer="Kevin Webter", DateOfService= new DateTime(2020,04,04), WorkCarriedOut="Oil changed, new wing mirror", Mileage=20000, ServiceCost=99.99};
            var s11= new Service {VehicleId=v9.Id, Servicer="B.A Baracus", DateOfService=new DateTime(2020,03,03), WorkCarriedOut="Inpection only", Mileage=15000, ServiceCost=29.99};

            //add services
            svc.AddService(s1);
            svc.AddService(s2);
            svc.AddService(s3);
            svc.AddService(s4);
            svc.AddService(s5);
            svc.AddService(s6);
            svc.AddService(s7);
            svc.AddService(s8);
            svc.AddService(s9);
            svc.AddService(s10);
            svc.AddService(s11);

        }
    }
}
   