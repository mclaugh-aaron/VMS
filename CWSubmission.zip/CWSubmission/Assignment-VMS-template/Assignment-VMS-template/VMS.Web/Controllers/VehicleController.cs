using System;
using VMS.Web.Controllers;
using VMS.Data.Models;
using VMS.Data.Services;
using VMS.Web.ViewModels;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

using VMS.Data.Repositories;

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace VMS.Web.Controllers
{

 public class VehicleController : BaseController
    {
    private readonly VehicleDbService svc; 
    
    public VehicleController()
    {
        ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
        svc = new VehicleDbService();
    }

    //GET / vehicle/Index
    public IActionResult Index(string sortOrder)    
    {
        ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
        
        var vehicles = svc.GetAllVehicles(sortOrder);

        return View(vehicles);
    }   

    //Get/Vehicle/Details/ {id}
    public IActionResult Details(int id)
    {
        ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
        var vehicle = svc.GetVehicleById(id);
        if(vehicle == null)
        {
            return NotFound();
        }
        return View(vehicle);
    }

    //GET /Vehicle/Create
    public IActionResult Create()
    {
        ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
        //render blank form
        return View();
    }

    [HttpPost]
    public IActionResult Create (Vehicle v)
    {
        ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
        if(ModelState.IsValid)
        {
            svc.AddVehicle(new Vehicle{Make = v.Make, Model = v.Model, RegPlate=v.RegPlate, DateRegistered=v.DateRegistered, Transmission = v.Transmission, Co2Rating=v.Co2Rating, FuelType=v.FuelType, BodyType=v.BodyType, Doors=v.Doors, PhotoUrl=v.PhotoUrl});
            Alert("Vehicle successfully added", AlertType.success);
            return RedirectToAction(nameof(Index));
            //(v.Make, v.Model, v.DateRegistered, v.CarAge, v.Transmission, v.Co2Rating, v.FuelType, v.BodyType, v.Doors, v.PhotoUrl);
        }
        // redisplay the form for editing as there are validation errors
        return View(v);
    }

    //GET / vehicle/ edit/ {id}
    public IActionResult Edit(int id)
    {
        ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
        var vehicle = svc.GetVehicleById(id);
        if(vehicle == null)
        {
            return NotFound();
        }
        return View(vehicle);
    }

    [HttpPost]
    public IActionResult Edit(int id, Vehicle v)
    {
        ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
        if(ModelState.IsValid)
        {
            svc.UpdateVehicle(id, v);
            Alert("Vehicles details succesfully editted", AlertType.success);
            return RedirectToAction(nameof(Index));
        }
        return View(v);
    }

        // GET / vehicle/delete/{id}
        public IActionResult Delete(int id)
        {
            ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
            // load student via service         
            var vehicle = svc.GetVehicleById(id);
            if (vehicle == null)
            {
                return NotFound();
            }
            // pass student to view for deletion confirmation
            return View(vehicle);
        }

        // POST /vehicle/delete/{id}
        [HttpPost]
        public IActionResult DeleteConfirm(int id)
        {
            ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
            // delete student via service
            svc.DeleteVehicle(id);
            Alert("Vehicle successfully deleted", AlertType.danger);
            // redirect to the index view
            return RedirectToAction(nameof(Index));
        }   

            //-------Service Controllers------//


        //GET /vehicle/Create Service/{id}
        public IActionResult AddNewService (int id)
        {
            ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
            //verify that vehicle is accessible
            var s = svc.GetVehicleById(id);
            if(s == null)
            {
                return NotFound();
            }
            ViewBag.CarReg = s.RegPlate;
            //create a ticket view model
            var svm = new ServiceViewModel{VehicleId = id};
                
            //render form
            return View(svm);
        }   

        //POST /Vehicle/ create service/ {ID}
        [HttpPost]
        public  IActionResult AddNewService(ServiceViewModel s)
        {
            ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
            if(ModelState.IsValid)
            {
                svc.AddNewService(s.VehicleId, s.Servicer, s.WorkCarriedOut, s.ServiceCost, s.Mileage);
                Alert("Service successfully added", AlertType.success);
                return RedirectToAction("Details", new {Id = s.VehicleId});
            }
            return View(s);
        }



        // GET / service/delete/{id}
        public IActionResult DeleteService(int id)
        {
            ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
            // load student via service         
            var service = svc.GetServiceById(id);
            if (service == null)
            {
                return NotFound();
            }
            // pass student to view for deletion confirmation
            return View(service);
        }


        // POST /vehicle/delete/{id}
        [HttpPost]
        public IActionResult DeleteServiceConfirm(int id)
        {
            ViewBag.DateAndTime = $"Current date and time is: {DateTime.Now}";
            var service = svc.GetServiceById(id);
            // delete service via service
            svc.DeleteService(id);
            Alert("Service successfully deleted", AlertType.danger);
            // redirect to the vehicle details view
            return RedirectToAction("Details", new{Id = service.VehicleId});
        }  
        
}
}