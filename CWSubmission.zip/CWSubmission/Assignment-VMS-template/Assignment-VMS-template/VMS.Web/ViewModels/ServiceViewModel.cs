using System;
using VMS.Data.Models;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace VMS.Web.ViewModels
{
        public class ServiceViewModel
        {

            [Required] 
            public int VehicleId { get; set;}
            [Required]
            public string Servicer { get; set; }
            [Required]
            [StringLength(600, MinimumLength = 3)]
            public string WorkCarriedOut { get; set; }

            [Required] 
            [Range(1,999999)]
            public int Mileage { get; set; }
            [Required]
            [Range(1, 1000)]
            [DataType(DataType.Currency)]
            public double ServiceCost { get; set; }
        
         }
}
