using System;
using Xunit;

// importing dependencies from the Data Project
using VMS.Data.Models;
using VMS.Data.Services;

namespace VMS.Test
{
    public class TestVehicleService
    {
       // define a set of appropriate tests to test the vehicle service class
 
    }
}