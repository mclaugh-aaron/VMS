using System;
using VMS.Data.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace VMS.Data.Repositories
{
    public class VehicleDbContext : DbContext
    {
        // complete the context
        
    }
}