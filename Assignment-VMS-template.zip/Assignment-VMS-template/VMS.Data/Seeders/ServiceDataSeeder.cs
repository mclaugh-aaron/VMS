using System;
using System.Collections.Generic;
using VMS.Data.Models;
using VMS.Data.Repositories;
using VMS.Data.Services;


namespace VMS.Data.Seeders
{
    public static class ServiceDataSeeder
    {
   
        public static void Seed(IVehicleService svc)
        {    
            // use the service to seed the database with sample data 
            // when running the web project            

        }
    }
}
   